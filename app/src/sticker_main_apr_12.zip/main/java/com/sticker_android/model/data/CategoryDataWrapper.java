package com.sticker_android.model.data;

import android.os.Parcelable;

import com.sticker_android.model.corporateproduct.Category;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by satyendra on 4/10/18.
 */

public class CategoryDataWrapper implements Serializable {

    public ArrayList<Category> categories;
}
