package com.sticker_android.model.interfaces;

/**
 * Created by user on 10/4/18.
 */

public interface CloseSearch {
    public void closeSearch();
}
