package com.sticker_android.model.interfaces;

public interface MessageEventListener {

	public void onOkClickListener(int reqCode);
}
