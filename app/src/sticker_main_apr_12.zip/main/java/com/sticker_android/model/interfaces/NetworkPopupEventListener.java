package com.sticker_android.model.interfaces;

public interface NetworkPopupEventListener {

	public void onOkClickListener(int reqCode);
	public void onRetryClickListener(int reqCode);
}
