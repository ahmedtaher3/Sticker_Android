package com.sticker_android.model.interfaces;

public interface OnLoadMoreListener {
	 void onLoadMore();
}
