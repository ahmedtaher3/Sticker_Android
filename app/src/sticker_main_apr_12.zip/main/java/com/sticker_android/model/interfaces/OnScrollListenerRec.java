package com.sticker_android.model.interfaces;

/**
 * Created by user on 4/4/18.
 */

public interface OnScrollListenerRec {

    public void onScroll(boolean isHideShow);
}
