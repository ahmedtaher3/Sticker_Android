package com.sticker_android.network;

/**
 * Created by root on 26/12/16.
 */
public class ServerUtils {

    public static int SUCCESS = 200;
    public static int FAILURE = 600;

}
