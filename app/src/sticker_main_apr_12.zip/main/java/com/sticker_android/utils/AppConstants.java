package com.sticker_android.utils;

/**
 * Created by satyendra on 3/29/18.
 */

public class AppConstants {

    public static final boolean DEBUG_MODE = true;

    public static final int FAN = 0;

    public static final int DESIGNER = 1;

    public static final int CORPORATE = 2;
    public static final String USERSELECTION = "userSelection";

}
