package com.sticker_android.utils.fragmentinterface;

/**
 * Created by user on 10/4/18.
 */

public interface UpdateToolbarTitle {
 public    void  updateToolbarTitle(String name);
}
